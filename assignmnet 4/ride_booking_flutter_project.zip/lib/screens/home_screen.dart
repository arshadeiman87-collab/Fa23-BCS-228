
import 'package:flutter/material.dart';
import '../db/database_helper.dart';
import 'add_booking_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Map<String, dynamic>> bookings = [];

  void loadBookings() async {
    bookings = await DatabaseHelper.instance.getBookings();
    setState(() {});
  }

  @override
  void initState() {
    super.initState();
    loadBookings();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Ride Bookings')),
      body: ListView.builder(
        itemCount: bookings.length,
        itemBuilder: (context, index) {
          return Card(
            child: ListTile(
              title: Text(bookings[index]['name']),
              subtitle: Text('${bookings[index]['pickup']} → ${bookings[index]['dropoff']}'),
              trailing: IconButton(
                icon: const Icon(Icons.delete, color: Colors.red),
                onPressed: () async {
                  await DatabaseHelper.instance.deleteBooking(bookings[index]['id']);
                  loadBookings();
                },
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const AddBookingScreen()),
          );
          loadBookings();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
