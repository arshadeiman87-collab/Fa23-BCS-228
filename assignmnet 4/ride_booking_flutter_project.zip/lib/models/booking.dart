
class Booking {
  int? id;
  String name;
  String pickup;
  String dropoff;

  Booking({this.id, required this.name, required this.pickup, required this.dropoff});

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'pickup': pickup,
      'dropoff': dropoff,
    };
  }
}
